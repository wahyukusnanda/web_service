<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';
use Restserver\Libraries\REST_Controller;

class Pembayaran extends REST_Controller {

    function __construct($config = 'rest') {
        parent::__construct($config);		     
    }
    
	//Contoh penerapan idempotency pada method post resource pembayaran
	public function index_post() {
        $data = array(
                    'id_pembayaran'    => $this->post('id_pembayaran'),
                    'tgl_bayar'   => $this->post('tgl_bayar'),                   
					'total_bayar'   => $this->post('total_bayar'),  
					'id_transaksi'    => $this->post('id_transaksi'),
					'LastUpdate'    => $this->post('LastUpdate'));	
		$this->db->where("id_pembayaran",$this->post('id_pembayaran'));				
		$this->db->where("tgl_bayar",$this->post('tgl_bayar'));
		$check = $this->db->get("Pembayaran")->num_rows();
		if($check==0):
			$insert = $this->db->insert('Pembayaran', $data);
			if ($insert) {            
				$result = ["took"=>$_SERVER["REQUEST_TIME_FLOAT"],
							"code"=>201,
							"message"=>"Data has successfully added",
							"data"=>$data];	
				$this->response($result, 201);
			} else {
				$result = ["took"=>$_SERVER["REQUEST_TIME_FLOAT"],
					  "code"=>502,
					  "message"=>"Failed adding data",
					  "data"=>null];	
				$this->response($result, 502);            
			}
		else:
			$result = ["took"=>$_SERVER["REQUEST_TIME_FLOAT"],
					  "code"=>304,
					  "message"=>"Data already added.",
					  "data"=>null];	
				$this->response($result, 304); 
		endif;	
    }
	
	
    
}
?>