<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';
use Restserver\Libraries\REST_Controller;

class barang extends REST_Controller {

    function __construct($config = 'rest') {
        parent::__construct($config);
		$this->load->driver('cache', array('adapter' => 'apc', 'backup' => 'file'));				
    }

    //Menampilkan data 
    public function index_get() {			
        $id = $this->get('id');		
		$barang=[];
        if ($id == '') { 
            $data = $this->db->get('barang')->result();
			foreach($data as $row=>$key):
				$barang[]=["id_barang"=>$key->id_barang,
							 "nama_barang"=>$key->nama_barang,
							 "_links"=>[(object)["href"=>"pembayaran/{$key->id_pembayaran}",
											"rel"=>"pembayaran",
											"type"=>"GET"],
										(object)["href"=>"pembeli/{$key->id_pembeli}",
											"rel"=>"pembeli",
											"type"=>"GET"]],																					
							"id_barang"=>$key->id_barang,
							"nama_barang"=>$key->nama_barang,
							"harga"=>$key->harga,
							"stok"=>$key->stok,
							"id_supplier"=>$key->id_supplier,	
							"LastUpdate"=>$key->LastUpdate	
							 ];
			endforeach;
        } else {			
				$this->db->where('id_barang', $id);
				$data = $this->db->get('barang')->result();				
				$barang=["id_barang"=>$data[0]->id_barang,
								 "nama_barang"=>$data[0]->nama_barang,
								 "_links"=>[(object)["href"=>"pembayaran/{$data[0]->id_pembayaran}",
												"rel"=>"pembayaran",
												"type"=>"GET"],
											(object)["href"=>"pembeli/{$data[0]->id_pembeli}",
												"rel"=>"pembeli",
												"type"=>"GET"]],																					
								"id_barang"=>$data[0]->id_barang,
								"nama_barang"=>$data[0]->nama_barang,
								"harga"=>$data[0]->harga,
								"stok"=>$data[0]->stok,
								"id_supplier"=>$data[0]->id_supplier,	
								"LastUpdate"=>$data[0]->LastUpdate	
								 ];
						 			
		}	
		$etag = hash('sha256', $data[0]->LastUpdate);				 
		$this->cache->save($etag, $barang, 300);			
		$this->output->set_header('ETag:'.$etag);	
		$this->output->set_header('Cache-Control: must-revalidate');	
		if(isset($_SERVER['HTTP_IF_NONE_MATCH']) && $_SERVER['HTTP_IF_NONE_MATCH'] == $etag) {								
			$this->output->set_header('HTTP/1.1 304 Not Modified');
		}else{		
				$result = ["took"=>$_SERVER["REQUEST_TIME_FLOAT"],
						   "code"=>200,
					       "message"=>"Response successfully",
					       "data"=>$barang];	
				$this->response($result, 200);
			}
		
    }


	//Menambah data 
	public function index_post() {
        
    }
	
	//Memperbarui data yang telah ada
    public function index_put() {
        
    }
	
	// Menghapus data customers
	public function index_delete() {
        
    }
    
}
?>