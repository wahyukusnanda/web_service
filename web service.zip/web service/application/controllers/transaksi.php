<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';
use Restserver\Libraries\REST_Controller;

class transaksi extends REST_Controller {

    function __construct($config = 'rest') {
        parent::__construct($config);
		$this->load->driver('cache', array('adapter' => 'apc', 'backup' => 'file'));				
    }

    //Menampilkan data 
    public function index_get() {			
        $id = $this->get('id');		
		$transaksi=[];
        if ($id == '') { 
            $data = $this->db->get('transaksi')->result();
			foreach($data as $row=>$key):
				$transaksi[]=["id_transaksi"=>$key->id_transaksi,
							 //"nama_pembeli"=>$key->nama_pembeli,
					 		 "_links"=>[(object)["href"=>"pembeli/{$key->id_pembeli}",
											"rel"=>"pembeli",
											"type"=>"GET"],
										(object)["href"=>"barang/{$key->id_barang}",
											"rel"=>"barang",
											"type"=>"GET"]],																					
							//"id_transaksi"=>$key->id_transaksi,
							"id_barang"=>$key->id_barang,
							"id_pembeli"=>$key->id_pembeli,
							"tanggal"=>$key->tanggal,
							"keterangan"=> $key->keterangan,	
							"LastUpdate"=>$key->LastUpdate	
							 ];
			endforeach;
        } else {			
				$this->db->where('id_transaksi', $id);
				$data = $this->db->get('transaksi')->result();				
				$transaksi=["id_transaksi"=>$data[0]->id_transaksi,
								 //"nama_pembeli"=>$data[0]->nama_pembeli,
								 "_links"=>[(object)["href"=>"pembeli/{$data[0]->id_pembeli}",
												"rel"=>"pembeli",
												"type"=>"GET"],
											(object)["href"=>"barang/{$data[0]->id_barang}",
												"rel"=>"barang",
												"type"=>"GET"]],																					
								//"id_transaksi"=>$data[0]->id_transaksi,
								"id_barang"=>$data[0]->id_barang,
								"id_pembeli"=>$data[0]->id_pembeli,
								"tanggal"=>$data[0]->tanggal,
								"keterangan"=>$data[0]->keterangan,	
								"LastUpdate"=>$data[0]->LastUpdate	
								 ];
						 			
		}	
		$etag = hash('sha256', $data[0]->LastUpdate);				 
		$this->cache->save($etag, $transaksi, 300);			
		$this->output->set_header('ETag:'.$etag);	
		$this->output->set_header('Cache-Control: must-revalidate');	
		if(isset($_SERVER['HTTP_IF_NONE_MATCH']) && $_SERVER['HTTP_IF_NONE_MATCH'] == $etag) {								
			$this->output->set_header('HTTP/1.1 304 Not Modified');
		}else{		
				$result = ["took"=>$_SERVER["REQUEST_TIME_FLOAT"],
						   "code"=>200,
					       "message"=>"Response successfully",
					       "data"=>$transaksi];	
				$this->response($result, 200);
			}
		
    }


	//Menambah data 
	public function index_post() {
        
    }
	
	//Memperbarui data yang telah ada
    public function index_put() {
        
    }
	
	// Menghapus data customers
	public function index_delete() {
        
    }
    
}
?>