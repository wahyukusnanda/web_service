<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';
require "vendor\autoload.php";

use Restserver\Libraries\REST_Controller;
use \Firebase\JWT\JWT; 
class products extends REST_Controller {

    function __construct($config = 'rest') {
        parent::__construct($config);			
    }

    //Menampilkan data 
    public function index_get() {
        $authHeader = $this->input->get_request_header('Authorization');		
		$arr = @explode(" ", $authHeader);
		$jwt = isset($arr[1])? $arr[1] : "";
		$secretkey = base64_encode("gampang");  
		if($jwt){		
			$id = $this->get('id');
			try{
				$decode = JWT::decode($jwt, $secretkey, array('HS256'));
				$id = $this->get('id');
				if ($id == '') {
					$data = $this->db->get('barang')->result();
				} else {
					$this->db->where('id_barang', $id);
					$data = $this->db->get('barang')->result();
				}				
				$result = ["took"=>$_SERVER["REQUEST_TIME_FLOAT"],
						"code"=>200,
						"message"=>"Response successfully",
						"data"=>$data];	
					$this->response($result, 200);
			}catch (Exception $e){
				$result = ["took"=>$_SERVER["REQUEST_TIME_FLOAT"],
						"code"=>401,
						"message"=>"Access denied",
						"data"=>null];	
				$this->response($result, 401);
			}
        }else{
			$result = ["took"=>$_SERVER["REQUEST_TIME_FLOAT"],
						  "code"=>401,
						  "message"=>"Access denied",
						  "data"=>null];	
			$this->response($result, 401);
		}			
    }

	//Menambah data 
	public function index_post() {
		$authHeader = $this->input->get_request_header('Authorization');		
		$arr = explode(" ", $authHeader);
		$jwt = isset($arr[1])? $arr[1] : "";
		$secretkey = base64_encode("gampang");  
		if($jwt){
			$data = array(
						'harga'    => $this->post('harga'),
						'id_barang'   => $this->post('id_barang'),
						'id_supplier'   => $this->post('id_supplier'),
						'stok'   => $this->post('stok'),                    
						'nama_barang'    => $this->post('nama_barang'));
			$insert = $this->db->insert('barang', $data);
			if ($insert) {            
				$result = ["took"=>$_SERVER["REQUEST_TIME_FLOAT"],
							"code"=>201,
							"message"=>"Data has successfully added",
							"data"=>$data];	
				$this->response($result, 201);
			} else {
				$result = ["took"=>$_SERVER["REQUEST_TIME_FLOAT"],
					"code"=>502,
					"message"=>"Failed adding data",
					"data"=>null];	
				$this->response($result, 502);   
			}
			}else{
				$result = ["took"=>$_SERVER["REQUEST_TIME_FLOAT"],
							"code"=>401,
							"message"=>"Access denied",
							"data"=>null];	
				$this->response($result, 401);
			
		}
	}
	
	//Memperbarui data yang telah ada
    public function index_put() {
		$authHeader = $this->input->get_request_header('Authorization');		
		$arr = explode(" ", $authHeader);
		$jwt = isset($arr[1])? $arr[1] : "";
		$secretkey = base64_encode("gampang");  
		if($jwt){
			$id = $this->put('barang');
			$data = array(
						'harga'    => $this->put('harga'),
						'id_barang'   => $this->put('id_barang'),
						'id_supplier'   => $this->put('id_supplier'),
						'stok'   => $this->put('stok'),                    
						'nama_barang'    => $this->put('nama_barang'));
			$this->db->where('id_barang', $id);
			$update = $this->db->update('id_barang', $data);
			if ($update) {
				$this->response($data, 200);
			} else {
				$this->response(array('status' => 'fail', 502));
			}
			}else{
				$result = ["took"=>$_SERVER["REQUEST_TIME_FLOAT"],
							"code"=>401,
							"message"=>"Access denied",
							"data"=>null];	
				$this->response($result, 401);
		}
    }
	
	// Menghapus data customers
	public function index_delete() {
		$authHeader = $this->input->get_request_header('Authorization');		
		$arr = explode(" ", $authHeader);
		$jwt = isset($arr[1])? $arr[1] : "";
		$secretkey = base64_encode("gampang");  
		if($jwt){
			$id = $this->delete('id_barang');
			$this->db->where('id_barang', $id);
			$delete = $this->db->delete('barang');
			if ($delete) {
				$this->response(array('status' => 'success'), 201);
			} else {
				$this->response(array('status' => 'fail', 502));
			}
			}else{
				$result = ["took"=>$_SERVER["REQUEST_TIME_FLOAT"],
							"code"=>401,
							"message"=>"Access denied",
							"data"=>null];	
				$this->response($result, 401);
			}
	}
}
?>